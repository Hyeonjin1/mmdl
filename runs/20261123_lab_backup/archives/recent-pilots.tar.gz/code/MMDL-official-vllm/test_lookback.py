"""Regression checks for cumulative chunks, strict cooldown and prefix reuse."""
from types import SimpleNamespace
import unittest

from lookback import BUDGET, Controller, MAX_LOOKBACKS, WINDOW


class CharacterTokenizer:
    def encode(self, text, **kwargs):
        return list(map(ord, text))

    def decode(self, tokens, **kwargs):
        return "".join(map(chr, tokens))


class FakeEngine:
    def __init__(self, continuations, tokenizer, vision):
        self.continuations = iter(continuations)
        self.tokenizer = tokenizer
        self.vision = vision

    def generate(self, prompts, params, *, observe):
        prompt, = prompts
        assert prompt["multi_modal_data"] is self.vision
        raw = prompt.get("prompt_token_ids", self.tokenizer.encode(prompt.get("prompt", "")))
        # Simulate vLLM expanding the image placeholder at the start of the prompt.
        prompt_ids = [900, 901] + raw
        text = next(self.continuations)
        for end in range(10, len(text) + 10, 10):
            tokens = self.tokenizer.encode(text[:end])
            finished = end >= len(text)
            answer = SimpleNamespace(token_ids=tokens, finish_reason="stop" if finished else None)
            output = SimpleNamespace(outputs=[answer], finished=finished, prompt_token_ids=prompt_ids,
                                     num_cached_tokens=0)
            if observe(output) or finished:
                return [output]


class LookbackTests(unittest.TestCase):
    def setUp(self):
        self.tokenizer = CharacterTokenizer()

    def run_chunks(self, continuations, enabled=True):
        vision = object()
        engine = FakeEngine(continuations, self.tokenizer, vision)
        controller = Controller(self.tokenizer, enabled)
        text, finish = controller.generate(
            engine, {"prompt": "hold on Therefore,", "multi_modal_data": vision}, lambda n: n)
        self.assertEqual(finish, "stop")
        return controller, text

    def test_early_interrupt_and_followup(self):
        first = "I need to"
        gap = "x" * 43 + " hold on"
        controller, text = self.run_chunks([first + " DISCARDED", gap + " DISCARDED",
                                            "Therefore, let me check once."])
        events = controller.events
        self.assertEqual([e["generated_position"] for e in events], [len(first), len(first)+WINDOW+1])
        self.assertEqual(events[1]["generated_since_last_trigger"], WINDOW+1)
        expected = first + "\n" + events[0]["insertion_phrase"] + " " + gap
        expected += "\n" + events[1]["insertion_phrase"] + " Therefore, let me check once."
        self.assertEqual(text, expected)
        self.assertEqual(controller.first_blocked_pause["phrase"], "let me check")
        self.assertTrue(all(s["resumed_prefix_verified"] for s in controller.segments[1:]))
        self.assertGreater(controller.segments[0]["unaccepted_streamed_tokens"], 0)

    def test_answer_phase_before_pause(self):
        controller, text = self.run_chunks(["Therefore, I need to pick B."])
        self.assertFalse(controller.events)
        self.assertEqual(controller.answer_phase["generated_position"], len("Therefore,"))
        self.assertEqual(controller.first_blocked_pause["phrase"], "I need to")
        self.assertEqual(text, "Therefore, I need to pick B.")

    def test_maximum_insertions_and_no_prompt_matching(self):
        first = "I need to ... more"
        gap = "x" * 43 + " hold on ... more"
        controller, _ = self.run_chunks([first, *([gap] * MAX_LOOKBACKS)])
        self.assertEqual(len(controller.events), MAX_LOOKBACKS)
        self.assertEqual(controller.first_pause["generated_position"], len("I need to"))
        self.assertIsNone(controller.answer_phase)

    def test_budget_refuses_insertion_without_continuation_space(self):
        controller = Controller(self.tokenizer, enabled=True)
        controller.trace = [ord("x")] * (BUDGET - len("hold on") - 2)
        controller.generated = len(controller.trace)
        for token in map(ord, "hold on"):
            self.assertFalse(controller.consume(token))
        self.assertIsNone(controller.pending)
        self.assertEqual(len(controller.trace), BUDGET-2)


if __name__ == "__main__":
    unittest.main()
