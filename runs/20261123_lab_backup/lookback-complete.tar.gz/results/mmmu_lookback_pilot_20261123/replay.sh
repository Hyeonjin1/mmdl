#!/usr/bin/env bash
set -euo pipefail

output=$(cd -- "$(dirname -- "$0")" && pwd)
cd -- "$output/../.."
runtime=/home/gpu/projects/mmdl-b0.UjOD9U
stage=${1:-run}
if [[ "$stage" == launch ]]; then
    [[ -f "$output/smoke/passed.json" ]]
    nohup bash "$output/replay.sh" run </dev/null >>"$output/run.log" 2>&1 &
    pid=$!
    echo "$pid" > "$output/run.pid"
    echo "Pilot process: $pid"
    exit
fi

if [[ "$stage" == status ]]; then
    python3 code/MMDL-official-vllm/lookback_report.py "$output"
    python3 -c 'import json, pathlib, sys; d = pathlib.Path(sys.argv[1]); paths = (d / "smoke/summary.json", d / "summary.json"); print({str(p.relative_to(d)): (q["pairs"], q["expected_per_condition"]) for p in paths if p.exists() for q in [json.loads(p.read_text())]})' "$output"
    if [[ -f "$output/run.log" ]]; then
        tail -12 "$output/run.log"
    else
        tail -12 "$output/smoke.log"
    fi
    exit
fi

export CC="$runtime/.toolchain/env/bin/x86_64-conda-linux-gnu-gcc"
export CPATH="$runtime/.toolchain/env/include/python3.12"
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1 CUDA_VISIBLE_DEVICES=0
export VLLM_WORKER_MULTIPROC_METHOD=spawn PYTHONUNBUFFERED=1
trap 'python3 code/MMDL-official-vllm/lookback_report.py "$output"' EXIT

"$runtime/.venv/bin/python" code/MMDL-official-vllm/lookback_pilot.py "$stage" \
    --output "$output" \
    --images /home/gpu/projects/mmdl-lookback.0XCHOF/image_manifest.json \
    --model "$runtime/hf/hub/models--Qwen--Qwen3-VL-4B-Instruct/snapshots/ebb281ec70b05090aa6165b016eac8ec08e71b17" \
    --official-mmmu "$runtime/official-mmmu"
